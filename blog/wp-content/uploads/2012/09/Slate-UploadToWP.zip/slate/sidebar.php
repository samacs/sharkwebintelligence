				<div id="sidebar-wrap">
					<a id="sidebar-close" href="#" title="close"></a>
					<div id="sidebar">
						<?php dynamic_sidebar('Sidebar'); ?>
					</div><!-- sidebar -->
				</div><!-- sidebar wrap-->